<template>
  <div>
    <SimpleFooter/>
    <SimpleForm/>
  </div>
</template>

<script>
  import SimpleFooter from './components/SimpleFooter'
  import SimpleForm from './components/SimpleForm'
  
  export default {
    data() {
      return {

      }
    },
    components: {SimpleFooter, SimpleForm}
  }
</script>

<style>

</style>

