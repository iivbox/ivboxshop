import SimpleForm from './SimpleForm'

export default SimpleForm