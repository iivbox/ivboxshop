import SimpleLogin from './SimpleLogin'

export default SimpleLogin