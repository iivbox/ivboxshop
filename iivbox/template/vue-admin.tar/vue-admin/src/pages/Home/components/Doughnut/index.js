import Doughnut from './Doughnut'

export default Doughnut