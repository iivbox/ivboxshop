export const asideMenuConfig = [
  {
    path: '/home',
    name: '主页',
    icon: 'ios-navigate'
  },
  {
    path: '/form',
    name: '表单页',
    icon: 'ios-settings'
  },
  {
    path: '/notfound',
    name: '404页面',
    icon: 'ios-settings'
  },
];
