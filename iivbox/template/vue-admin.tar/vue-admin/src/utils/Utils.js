/**
 * 工具类方法1
 * @param {*} 
 * @returns {String}
 */
export const test = () => {
  return 'utils';
}