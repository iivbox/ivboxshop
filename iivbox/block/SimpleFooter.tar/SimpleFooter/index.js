import SimpleFooter from './SimpleFooter'

export default SimpleFooter