import OperateTable from './OperateTable'

export default OperateTable